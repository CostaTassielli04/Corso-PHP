<?php


function doDefault(){
    
echo <<< FINE
    
        <div class="jumbotron">
                 <h2>Vuoi comprare un auto? La vuoi restituire?</h2>
                 <p>Clicca su home per vedere tutti gli ordini già svolti <br /></p>
                 <p>Clicca sul form per inserire le clausole da soddisfare nella ricerca</p>         
        </div>
FINE;
}

