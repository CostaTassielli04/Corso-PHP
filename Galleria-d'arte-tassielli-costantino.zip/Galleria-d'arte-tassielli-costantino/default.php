<?php

/* 
 * default.php
 * 
 * Descrivi il contenuto predefinito se non viene scelta alcuna opzione
 */

function doDefault(){
    
echo <<< FINE
    
        <div class="jumbotron">
                 <h2>Benvenuto nel nostro Museo</h2>
                 <p>Acquista il biglietto per poter partecipare alla nostra mostra<br /></p>
                 <p>Cosa aspetti,corri in ufficio!!</p>
                 
        </div>
FINE;
}

